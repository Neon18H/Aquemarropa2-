class Categoria{
  late int id;
  late String name; 
  late String foot;
  
  Categoria(this.id, this.name, this.foot); 
  
}

final Cajas = [
  Categoria(1, "Conejo", "Conejomorado.png"),
 ];

